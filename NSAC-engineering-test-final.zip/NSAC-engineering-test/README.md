# NSAC Engineering Test

Reusable, mobile + desktop technical examination interface for the NSAC team.

## Current specification
- 2-hour examination
- 100 marks / 13 problems
- Candidate name only; no candidate ID required
- Autosaves answers continuously in the candidate's browser
- Restores an unfinished examination after refresh/reopen on the same browser/device
- Mobile and desktop responsive layouts
- Reference Library and supplied visual/reference panels
- No correctness feedback during the examination
- Final submission produces a clean examination-paper file and a machine-readable JSON backup
- Email submission is designed to use EmailJS; configure it once for the repository, then reuse the same test link for other candidates

## One-time email setup
The test uses EmailJS so no custom backend server is required. EmailJS supports client-side sending and dynamic attachments. See the official documentation:
https://www.emailjs.com/docs/introduction/how-does-emailjs-work/

1. Create an EmailJS account and connect the email service you want to use.
2. Create one email template. Set the **To** address to the examiner's email.
3. In the template, make the email body minimal, for example:
   `New NSAC Engineering Test submission — {{candidate_name}} — {{submitted_at}} — {{time_used}}`
4. Add two **Variable Attachments** in the template's Attachments tab:
   - Parameter name: `paper` | Filename: `{{paper_filename}}` | Content type: `text/html`
   - Parameter name: `data` | Filename: `{{data_filename}}` | Content type: `application/json`
5. Copy your EmailJS Public Key, Service ID and Template ID.
6. Open `TEST.html` and replace these three placeholders near the top:
   - `YOUR_EMAILJS_PUBLIC_KEY`
   - `YOUR_EMAILJS_SERVICE_ID`
   - `YOUR_EMAILJS_TEMPLATE_ID`
7. Deploy the repository as a normal static website (for example with GitHub Pages).

The candidate does **not** configure anything. The same deployed test can be reused for any number of candidates. They enter only their name. The submission email subject/body can use the candidate name automatically through the EmailJS template.

## What arrives by email
The email is intentionally minimal. The actual submission is in attachments:

- `NSAC-Engineering-Test-<name>.html` — a clean, paper-like answer script that can be opened in a browser and printed to PDF if desired.
- `NSAC-Engineering-Test-<name>.json` — machine-readable backup of the complete submission.

No human-readable wall of answers is placed in the email body.

## Important deployment note
EmailJS configuration contains a public browser key by design. Do not put a private EmailJS access token into `TEST.html`. The EmailJS public key is intended for client-side use.

The test itself can be worked on while offline after it has loaded; autosave is local. Final email submission requires an internet connection.

## Repository use
For each new candidate, use the same deployed URL. Do not make a copy of the repository per candidate. Candidate answers are stored locally in that candidate's browser and the final submission email is generated with that candidate's name.
